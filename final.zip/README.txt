========================================
  AnomFIN Website - Final Package
========================================

Thank you for choosing AnomFIN!

This package contains everything you need to deploy the AnomFIN website.

QUICK START (3 STEPS):
1. Extract all files to your web server directory
2. Open browser: http://your-domain.com/install.php
3. Fill in database details and click "Asenna nyt"

Done! Your site is ready.

WHAT'S INCLUDED:
- Static website (HTML/CSS/JS)
- PHP backend with database support
- AI service integration
- One-time installation wizard
- Admin panel for management

FOR STATIC SITE ONLY:
Just upload files and access index.html - no installation needed!

FOR FULL SYSTEM:
1. Upload files to web hosting
2. Create MySQL database
3. Run install.php in browser
4. Access admin.php panel

For support, contact: info@anomfin.fi

Visit us at: https://anomfin.fi

© 2025 AnomFIN - Cybersecurity & Application Development
