<?php
return [
    'password_hash' => '$2y$12$SpWLxei6oJv1A6KQs1HsmeahYdlXTpiGwgRXx9hIUcBuH9WxzMGG2',
    'session_key' => 'anomfin_admin_authenticated',
    'session_user_key' => 'anomfin_admin_name',
    'default_admin_name' => 'AnomFIN | AnomTools',
    'settings_file' => __DIR__ . '/../data/settings.json',
];
