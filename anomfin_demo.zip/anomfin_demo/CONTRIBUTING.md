# Contributing

- Pidä sisältö mahdollisimman datavetoisena: muokkaa `content/site.json`.
- Älä kovakoodaa tekstejä komponentteihin.
- Käytä saavutettavia HTML-elementtejä ja aria-merkintöjä.
- Vältä ylimääräisiä kirjastoja ellei ole tarvetta.

## Commit-viestit
Käytä muotoa: `feat: ...`, `fix: ...`, `docs: ...`, `chore: ...`.
