# TODO

- [ ] Korvaa mailto-linkit ajanvarauskalenterilla (Calendly tms.).
- [ ] Lisää referenssit (logot + sitaatit) `content/site.json`.
- [ ] Tietosuoja- ja evästesivu (FI).
- [ ] Plausible-analytiikka (ilman evästebanneria).
- [ ] Siirto Astro/Next -projektiin (datavetoinen).

# COPILOT_TODO
- [ ] Scaffold Astro.
- [ ] Lue content/site.json ja generoi sivut.
- [ ] Luo reitit ja komponentit.
- [ ] Lisää i18n-valmius.
